#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("You're in help.\n");
    return 0;
}
